export type ProjectCategory =
  | 'All'
  | 'Baby Memory Books'
  | 'Baby Journals'
  | 'eBook Covers'
  | 'eBook Interior Design'
  | 'Keepsake Journals'
  | 'Personalized Books';

export interface ServiceItem {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  description: string;
  image: string;
  deliverables: string[];
  idealFor: string;
  timeline: string;
}

export interface PortfolioItem {
  id: string;
  title: string;
  category: ProjectCategory;
  subtitle: string;
  coverImage: string;
  additionalImages?: string[];
  clientSnippet: string;
  description: string;
  details: string[];
  dimensions?: string;
}

export interface TestimonialItem {
  id: string;
  quote: string;
  author: string;
  location: string;
  projectCategory: string;
  year: string;
}

export interface SampleJournalAngle {
  id: string;
  tabLabel: string;
  title: string;
  description: string;
  image: string;
  features: string[];
}

export interface InquiryFormData {
  name: string;
  email: string;
  phone?: string;
  projectType: string;
  timeline: string;
  budgetRange?: string;
  message: string;
}
