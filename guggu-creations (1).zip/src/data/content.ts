import { ServiceItem, PortfolioItem, TestimonialItem, SampleJournalAngle } from '../types';

export const HERO_IMAGE = '/assets/images/hero_mother_baby_1789618302594.jpg';
export const FEATURED_BOOK_IMAGE = '/assets/images/baby_memory_book_1789618319092.jpg';
export const STUDIO_DESK_IMAGE = '/assets/images/studio_desk_1789618331566.jpg';
export const JOURNAL_SPREADS_IMAGE = '/assets/images/journal_spreads_1789618347235.jpg';
export const FAMILY_MOMENT_IMAGE = '/assets/images/family_moment_1789618363197.jpg';

export const SERVICES: ServiceItem[] = [
  {
    id: 'ebook-writing',
    number: '01',
    title: 'eBook Writing',
    subtitle: 'Narrative structure & thoughtful prose',
    description:
      'Transform ideas, expertise, and stories into polished digital books with a clear structure, poetic pacing, and engaging flow.',
    image:
      'https://images.unsplash.com/photo-1455390582262-044cdead277a?auto=format&fit=crop&w=1200&q=80',
    deliverables: [
      'Comprehensive content outline & narrative blueprint',
      'Editorial chapter drafting & voice development',
      'Professional copyediting & proofreading passes',
      'Author notes, dedication pages, and foreword curation'
    ],
    idealFor: 'Writers, educators, lifestyle mentors, and storytellers seeking a ghostwriting or structuring partner.',
    timeline: '3–6 weeks depending on word count'
  },
  {
    id: 'ebook-design',
    number: '02',
    title: 'eBook Design',
    subtitle: 'Typography, layouts & art direction',
    description:
      'Beautiful layouts, typography, covers, and visual systems designed to make digital books feel tactile, premium, and professionally published.',
    image:
      'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=1200&q=80',
    deliverables: [
      'Bespoke cover design (EPUB, PDF, and print-ready)',
      'Custom typographic hierarchy & drop-cap styling',
      'Interactive PDF, fixed-layout EPUB, and reflowable files',
      'Editorial chapter openers and pull-quote treatments'
    ],
    idealFor: 'Independent authors, boutique brands, and self-publishers looking for editorial luxury.',
    timeline: '2–3 weeks'
  },
  {
    id: 'baby-journals',
    number: '03',
    title: 'Baby Journals',
    subtitle: 'Heirloom milestone prompts & gentle guidance',
    description:
      'Elegant milestone journals created to preserve those fleeting early months with space for handwritten thoughts, tiny triumphs, and tender memories.',
    image: FEATURED_BOOK_IMAGE,
    deliverables: [
      'Guided prompts for pregnancy through Year One and beyond',
      'Minimalist milestone trackers (first smiles, sounds, rituals)',
      'Family heirloom pages for letters from parents and grandparents',
      'Digital interactive journal + archival print-ready file'
    ],
    idealFor: 'New parents, expectant mothers, and loved ones seeking a deeply personal baby shower gift.',
    timeline: '2–4 weeks'
  },
  {
    id: 'baby-memory-books',
    number: '04',
    title: 'Baby Memory Books',
    subtitle: 'Photo-led preserves of early childhood',
    description:
      'Photo-led memory books that turn everyday candid moments into treasured keepsakes through generous white space and museum-quality page pacing.',
    image:
      'https://images.unsplash.com/photo-1519689680058-324335c77eba?auto=format&fit=crop&w=1200&q=80',
    deliverables: [
      'Custom photo layout curation & tonal color balance',
      'Tender captioning and milestone documentation',
      'Hardcover cloth-bound print specifications',
      'High-resolution archival PDF delivery'
    ],
    idealFor: 'Families who have hundreds of camera-roll photos and want a cohesive printed heirloom.',
    timeline: '3–4 weeks'
  },
  {
    id: 'keepsake-journals',
    number: '05',
    title: 'Keepsake Journals',
    subtitle: 'For weddings, travels & life chapters',
    description:
      'Personalized journals designed around meaningful life chapters, vows, golden anniversaries, generational family recipes, or quiet grief and remembrance.',
    image:
      'https://images.unsplash.com/photo-1471107340929-a87cd0f5b5f3?auto=format&fit=crop&w=1200&q=80',
    deliverables: [
      'Tailored question sets and chapter themes',
      'Archival layout grids honoring personal ephemera',
      'Hand-lettered quote styling & decorative botanical accents',
      'Foil-stamping cover vector artwork'
    ],
    idealFor: 'Couples, travelers, generational families, and those marking commemorative milestones.',
    timeline: '3–5 weeks'
  },
  {
    id: 'personalized-book-design',
    number: '06',
    title: 'Personalized Book Design',
    subtitle: 'One-of-a-kind bespoke commissions',
    description:
      'Custom book concepts created from the ground up around your photographs, written story, chosen palette, and individual sentimental aesthetic.',
    image:
      'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=1200&q=80',
    deliverables: [
      'One-on-one creative vision consultation with our art director',
      'Custom cover illustration, monograms, or foil typography',
      'Unlimited revisions on editorial layout spreads',
      'Full physical print coordination or digital distribution package'
    ],
    idealFor: 'Clients wanting a truly singular bespoke art piece with uncompromising personal detail.',
    timeline: '4–8 weeks'
  }
];

export const PORTFOLIO_ITEMS: PortfolioItem[] = [
  {
    id: 'the-first-year-elena',
    title: 'Elena’s Quiet First Year',
    category: 'Baby Memory Books',
    subtitle: 'A 140-page linen keepsake book documenting baby Elena’s first four seasons.',
    coverImage: FEATURED_BOOK_IMAGE,
    additionalImages: [
      JOURNAL_SPREADS_IMAGE,
      'https://images.unsplash.com/photo-1519689680058-324335c77eba?auto=format&fit=crop&w=1200&q=80'
    ],
    clientSnippet: 'The Montgomery Family',
    description:
      'Crafted with soft oat linen textures, gentle botanical accents, and minimalist photographic grids. Designed to honor the calm and chaotic moments alike with tender handwritten parent reflections.',
    details: [
      'Trim Size: 9 × 11 in Landscape',
      'Paper: 160gsm Mohawk Superfine Eggshell',
      'Typography: Cormorant Garamond & Libre Baskerville',
      'Cover: Debossed Champagne Gold Foil on Oatmeal Bookcloth'
    ],
    dimensions: '9 × 11 in'
  },
  {
    id: 'letters-to-my-child',
    title: 'Letters to My Newborn Child',
    category: 'Baby Journals',
    subtitle: 'Guided prompts and parchment-lined blank pages for parental reflections.',
    coverImage:
      'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=1200&q=80',
    additionalImages: [
      JOURNAL_SPREADS_IMAGE,
      'https://images.unsplash.com/photo-1455390582262-044cdead277a?auto=format&fit=crop&w=1200&q=80'
    ],
    clientSnippet: 'Sophia & Liam K.',
    description:
      'An intimate journal structured across fifty-two weeks. Each spread pairs a tender seasonal prompt with ample blank breathing room for hand-written letters to be opened on the child’s eighteenth birthday.',
    details: [
      'Format: Interactive Digital Journal & Foil Hardcover',
      'Palette: Warm Ivory, Soft Sage, and Muted Champagne',
      'Special Features: Archival pocket for hospital bracelet and ultrasound'
    ],
    dimensions: '7.5 × 9.5 in'
  },
  {
    id: 'the-art-of-dwelling',
    title: 'The Art of Dwelling',
    category: 'eBook Covers',
    subtitle: 'Editorial typography & cover art direction for a slow-living architectural essay.',
    coverImage:
      'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&w=1200&q=80',
    clientSnippet: 'Celine Vance, Author',
    description:
      'A quiet, disciplined editorial book design highlighting intentional living, tactile spaces, and daylight. Features bespoke typesetting, custom drop caps, and negative-space cover design.',
    details: [
      'Format: Fixed-Layout EPUB & Amazon KDP Print',
      'Grid: 6-column asymmetric editorial layout',
      'Accolades: Featured on Minimalist Book Design Showcase'
    ],
    dimensions: '6 × 9 in'
  },
  {
    id: 'gathering-at-the-table',
    title: 'Gathering at the Hearth',
    category: 'eBook Interior Design',
    subtitle: 'Comprehensive interior layout system for an heirloom culinary anthology.',
    coverImage:
      'https://images.unsplash.com/photo-1476224203421-9ac39bcb3327?auto=format&fit=crop&w=1200&q=80',
    clientSnippet: 'The Laurent Collective',
    description:
      'Three generations of family recipes compiled into a 220-page digital and print keepsake book with full-bleed film photography, recipe cards, and handwritten side notes preserved in faithful facsimiles.',
    details: [
      'Pages: 220 full-color pages',
      'Typography: Custom display serif pairing',
      'Files: Interactive PDF with hyperlinked recipe index'
    ],
    dimensions: '8 × 10 in'
  },
  {
    id: 'ten-summers-together',
    title: 'Ten Summers on the Coast',
    category: 'Keepsake Journals',
    subtitle: 'A private anniversary retrospective tracing a decade of travels and shared memories.',
    coverImage:
      'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80',
    clientSnippet: 'Marcus & Clara D.',
    description:
      'Commissioned as a tenth-anniversary surprise gift, this linen-bound retrospective weaves together landscape photography, flight stubs, private poetry, and journal entries into an heirloom art object.',
    details: [
      'Binding: Hand-stitched layflat binding',
      'Embellishments: Sage ribbon marker & blind debossed cover title',
      'Edition: 3 bespoke heirloom copies'
    ],
    dimensions: '10 × 10 in Square'
  },
  {
    id: 'blooming-in-the-quiet',
    title: 'Blooming in the Quiet',
    category: 'Personalized Books',
    subtitle: 'Custom personal memoir and poetry collection for a multi-generational family.',
    coverImage:
      'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=1200&q=80',
    clientSnippet: 'Private Commission',
    description:
      'A deeply personal collaborative publishing project involving recorded oral history transcription, photograph restoration, and bespoke editorial layout across four generations.',
    details: [
      'Timeline: 8 weeks bespoke development',
      'Artwork: Hand-drawn botanical illustrations',
      'Format: Slipcased presentation edition'
    ],
    dimensions: '8.5 × 11 in'
  }
];

export const HOW_IT_WORKS_STEPS = [
  {
    number: '01',
    title: 'Tell us your story',
    description:
      'Share your idea, photographs, written notes, preferences, and personal vision through our thoughtful discovery questionnaire or consultation.'
  },
  {
    number: '02',
    title: 'We shape the design',
    description:
      'Your story is transformed into a thoughtful visual concept with curated typography, harmonious layouts, and a dedicated artistic direction.'
  },
  {
    number: '03',
    title: 'Refine the details',
    description:
      'Typography, imagery, delicate color palettes, photo crops, and intimate personal touches are carefully polished in collaborative feedback loops.'
  },
  {
    number: '04',
    title: 'Receive your finished book',
    description:
      'A beautiful digital keepsake and archival print-ready files delivered seamlessly, ready to download, bind, print, share, or treasure for generations.'
  }
];

export const SAMPLE_JOURNAL_ANGLES: SampleJournalAngle[] = [
  {
    id: 'closed-cover',
    tabLabel: 'Closed Cover',
    title: 'Heirloom Linen Cover',
    description:
      'Bound in tactile oatmeal linen with subtle blind debossing and champagne-gold foil script. Timeless, understated, and made to age gracefully on your coffee table or nursery shelf.',
    image: FEATURED_BOOK_IMAGE,
    features: ['Archival cotton bookcloth', 'Debossed gold foil titling', 'Stitched head & tail bands']
  },
  {
    id: 'interior-spread',
    tabLabel: 'Interior Spread',
    title: 'Balanced Editorial Spreads',
    description:
      'Generous margins and negative space give your photography and memories space to breathe. Each page is deliberately uncluttered, evoking fine-art gallery books.',
    image: JOURNAL_SPREADS_IMAGE,
    features: ['Generous 2-inch white borders', 'High-contrast serif headings', 'Subtle micro-grid alignment']
  },
  {
    id: 'photo-page',
    tabLabel: 'Photo Page',
    title: 'Gallery-Grade Photo Framing',
    description:
      'Whether candid smartphone snapshots or professional newborn studio sessions, our layouts calibrate image tones and framing to ensure every memory looks cohesive and cinematic.',
    image:
      'https://images.unsplash.com/photo-1519689680058-324335c77eba?auto=format&fit=crop&w=1200&q=80',
    features: ['Single and multi-photo layouts', 'Soft filmic tonal calibration', 'Captions with date & milestone']
  },
  {
    id: 'milestone-page',
    tabLabel: 'Milestone Page',
    title: 'Gentle Milestone Markers',
    description:
      'No overwhelming checklists or noisy graphics. We design subtle markers for first laughs, favorite songs, tiny footprints, and peaceful bedtime routines.',
    image:
      'https://images.unsplash.com/photo-1455390582262-044cdead277a?auto=format&fit=crop&w=1200&q=80',
    features: ['Minimalist milestone markers', 'Space for tiny keepsake clippings', 'Sensory memory highlights']
  },
  {
    id: 'prompt-page',
    tabLabel: 'Writing Prompt Page',
    title: 'Heartfelt Prompt Pages',
    description:
      'Guided prompts crafted to inspire deep, genuine parental reflections without feeling like a chore. Generous ruled or blank spaces invite handwritten letters.',
    image: STUDIO_DESK_IMAGE,
    features: ['Thoughtful introspective prompts', 'Ample lined writing room', 'Parent & grandparent letter sections']
  }
];

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: 'test-1',
    quote:
      'The final journal felt incredibly personal and beautifully polished. It turned our scattered photographs into something we will treasure for years. Opening the package brought tears of pure gratitude.',
    author: 'Eleanor Vance',
    location: 'Cotswolds, UK',
    projectCategory: 'Baby Memory Book',
    year: '2026'
  },
  {
    id: 'test-2',
    quote:
      'Working with Guggu Creations felt like having an editorial art director in our corner. Our eBook went from a rough draft to a museum-worthy publication that our readers constantly praise for its tactile beauty.',
    author: 'Julian & Margot S.',
    location: 'San Francisco, CA',
    projectCategory: 'eBook Design & Layout',
    year: '2026'
  },
  {
    id: 'test-3',
    quote:
      'From the delicate typography to the archival paper choice, the attention to detail is unmatched. It captured the exact calm, tender spirit of our daughter’s first months. A true heirloom.',
    author: 'Amara Chen',
    location: 'Melbourne, Australia',
    projectCategory: 'Keepsake Journal',
    year: '2025'
  }
];

export const SOCIAL_GALLERY_IMAGES = [
  {
    id: 'soc-1',
    title: 'Linen textures and foil accents',
    category: 'Details',
    image: FEATURED_BOOK_IMAGE
  },
  {
    id: 'soc-2',
    title: 'Tender nursery moments',
    category: 'Moments',
    image: HERO_IMAGE
  },
  {
    id: 'soc-3',
    title: 'Typographic study & serif proofs',
    category: 'Craft',
    image: STUDIO_DESK_IMAGE
  },
  {
    id: 'soc-4',
    title: 'Open interior spreads on stone',
    category: 'Layouts',
    image: JOURNAL_SPREADS_IMAGE
  },
  {
    id: 'soc-5',
    title: 'Tiny knitted booties and wild chamomile',
    category: 'Styling',
    image:
      'https://images.unsplash.com/photo-1519689680058-324335c77eba?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'soc-6',
    title: 'Afternoon light in the studio',
    category: 'Studio',
    image: FAMILY_MOMENT_IMAGE
  }
];

export const STUDIO_VALUES = [
  {
    title: 'Tactile Editorial Craft',
    description: 'We treat every digital and printed book with the rigorous typography and proportions of high-fashion monographs and fine art publishing.'
  },
  {
    title: 'Emotional Reverence',
    description: 'A baby’s early milestones, an author’s life work, and family histories deserve thoughtful honoring, never rushed or automated.'
  },
  {
    title: 'Subtle Modern Luxury',
    description: 'Calm ivory tones, quiet sage notes, generous whitespace, and restrained gold touches that outlast transient design fads.'
  }
];

export const FREQUENT_QUESTIONS = [
  {
    question: 'How do I send my photos and story notes?',
    answer: 'Once you submit your inquiry and we confirm your project, you will receive a secure private upload link where you can upload high-resolution images, drafts, and notes. We also provide a gentle guided questionnaire if you need inspiration.'
  },
  {
    question: 'Can you write the book or edit my existing text?',
    answer: 'Yes. Through our eBook Writing and Keepsake Storytelling services, we can ghostwrite from your interviews, refine your rough journal entries, or professionally copyedit your completed manuscript.'
  },
  {
    question: 'Do you provide physical printing or digital files?',
    answer: 'We provide both! All commissions include high-resolution, archival print-ready files (with proper bleed, color profiles, and binding margins) as well as optimized digital editions. We also coordinate with world-class heirloom bookbinders if you want us to handle printing and delivery directly to your door.'
  },
  {
    question: 'How long does a custom book project typically take?',
    answer: 'Standard baby journals and eBook design projects take 2 to 4 weeks. Fully personalized bespoke book commissions involving deep writing or custom illustration typically span 4 to 8 weeks to allow for thoughtful revision rounds.'
  }
];
