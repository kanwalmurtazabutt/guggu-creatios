/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Introduction } from './components/Introduction';
import { ServicesSection } from './components/ServicesSection';
import { FeaturedMemoryBook } from './components/FeaturedMemoryBook';
import { PortfolioGallery } from './components/PortfolioGallery';
import { HowItWorks } from './components/HowItWorks';
import { EmotionalStatement } from './components/EmotionalStatement';
import { SampleJournalPreview } from './components/SampleJournalPreview';
import { Testimonials } from './components/Testimonials';
import { AboutStudio } from './components/AboutStudio';
import { SocialGallery } from './components/SocialGallery';
import { ConversionCTA } from './components/ConversionCTA';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { ProjectModal } from './components/ProjectModal';
import { PortfolioItem, ServiceItem } from './types';

export default function App() {
  const [modalItem, setModalItem] = useState<PortfolioItem | ServiceItem | null>(null);
  const [modalType, setModalType] = useState<'portfolio' | 'service'>('portfolio');
  const [preselectedService, setPreselectedService] = useState<string>('Baby Memory Book');

  const scrollToSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleStartProject = (serviceName?: string) => {
    if (serviceName) {
      setPreselectedService(serviceName);
    }
    scrollToSection('contact');
  };

  const handleSelectPortfolio = (project: PortfolioItem) => {
    setModalItem(project);
    setModalType('portfolio');
  };

  const handleSelectService = (service: ServiceItem) => {
    setModalItem(service);
    setModalType('service');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F8F5EE] text-[#343434] selection:bg-[#AAB7A0]/25 selection:text-[#343434]">
      {/* Editorial Header */}
      <Header onStartProjectClick={() => handleStartProject()} />

      <main className="flex-grow">
        {/* 1. Hero Section */}
        <Hero
          onCreateKeepsakeClick={() => handleStartProject('Baby Memory Book')}
          onExploreWorkClick={() => scrollToSection('portfolio')}
        />

        {/* 2. Introduction Section */}
        <Introduction onDiscoverStudioClick={() => scrollToSection('about')} />

        {/* 3. Services Section */}
        <ServicesSection
          onSelectService={handleSelectService}
          onBookService={(serviceTitle) => handleStartProject(serviceTitle)}
        />

        {/* 4. Featured Baby Memory Book Showcase */}
        <FeaturedMemoryBook
          onViewJournalsClick={() => scrollToSection('portfolio')}
          onInquireClick={() => handleStartProject('Baby Memory Book')}
        />

        {/* 5. Editorial Portfolio / Gallery */}
        <PortfolioGallery onSelectProject={handleSelectPortfolio} />

        {/* 6. How It Works Section */}
        <HowItWorks />

        {/* 7. Emotional Brand Statement Banner */}
        <EmotionalStatement onCreateMeaningfulClick={() => handleStartProject('Keepsake Journal')} />

        {/* 8. Featured Sample Journal Section */}
        <SampleJournalPreview onExploreJournalClick={() => handleStartProject('Baby Journal')} />

        {/* 9. Testimonials Section */}
        <Testimonials />

        {/* 10. About Studio Section */}
        <AboutStudio onMeetStudioClick={() => scrollToSection('contact')} />

        {/* 11. Instagram / Social Visual Moodboard */}
        <SocialGallery />

        {/* 12. Final Conversion CTA */}
        <ConversionCTA
          onStartProjectClick={() => handleStartProject()}
          onViewPortfolioClick={() => scrollToSection('portfolio')}
        />

        {/* 13. Project Inquiry & Contact Section */}
        <ContactSection preselectedService={preselectedService} />
      </main>

      {/* 14. Editorial Footer */}
      <Footer />

      {/* Interactive Detail Modal for Portfolio & Services */}
      {modalItem && (
        <ProjectModal
          item={modalItem}
          type={modalType}
          onClose={() => setModalItem(null)}
          onInquire={(title) => {
            setModalItem(null);
            handleStartProject(title);
          }}
        />
      )}
    </div>
  );
}
