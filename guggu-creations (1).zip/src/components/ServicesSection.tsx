import React from 'react';
import { ArrowRight } from 'lucide-react';
import { SERVICES } from '../data/content';
import { ServiceItem } from '../types';

interface ServicesSectionProps {
  onSelectService: (service: ServiceItem) => void;
  onBookService: (serviceTitle: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({
  onSelectService,
  onBookService
}) => {
  return (
    <section
      id="services"
      className="relative bg-[#FBFAF6] py-24 sm:py-32 lg:py-36 px-6 sm:px-8 lg:px-12 border-b border-[#E7E0D6]"
    >
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 sm:mb-20 pb-8 border-b border-[#E7E0D6]">
          <div className="max-w-2xl">
            <span className="text-[11px] uppercase font-sans tracking-[0.24em] text-[#788875] font-medium block mb-3">
              Services &amp; Digital Publishing
            </span>
            <h2 className="font-serif text-[38px] sm:text-[48px] lg:text-[56px] leading-[1.12] text-[#343434] font-normal tracking-[-0.01em]">
              Thoughtfully designed for every chapter.
            </h2>
          </div>
          <p className="mt-4 md:mt-0 text-[15px] sm:text-[16px] text-[#77736C] max-w-sm font-sans leading-relaxed">
            From raw memories and manuscripts to refined heirlooms. Every project is crafted with editorial discipline and emotional warmth.
          </p>
        </div>

        {/* Editorial Grid: 2 columns on tablet, 3 columns on desktop */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-14 lg:gap-y-16">
          {SERVICES.map((service) => (
            <article
              key={service.id}
              id={`service-card-${service.id}`}
              className="group flex flex-col bg-[#F8F5EE] border border-[#E7E0D6] rounded-[2px] overflow-hidden transition-all duration-500 hover:shadow-[0_12px_32px_rgba(52,52,52,0.06)] hover:border-[#CBB58A]/50"
            >
              {/* Editorial Image Container */}
              <div className="relative aspect-[16/11] overflow-hidden bg-[#E7E0D6]">
                <img
                  src={service.image}
                  alt={service.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#343434]/40 via-transparent to-transparent opacity-60"></div>
                
                {/* Number Badge */}
                <div className="absolute top-4 left-4 bg-[#F8F5EE]/95 backdrop-blur-sm px-2.5 py-1 border border-[#E7E0D6] rounded-[1px]">
                  <span className="text-[11px] font-sans font-medium tracking-[0.16em] text-[#788875]">
                    {service.number}
                  </span>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 sm:p-7 flex flex-col flex-grow justify-between">
                <div>
                  <span className="text-[11px] uppercase font-sans tracking-[0.18em] text-[#CBB58A] block mb-2 font-medium">
                    {service.subtitle}
                  </span>
                  <h3 className="font-serif text-[24px] sm:text-[27px] leading-[1.2] text-[#343434] mb-3 group-hover:text-[#788875] transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-[14.5px] sm:text-[15px] leading-[1.65] font-sans text-[#77736C] mb-6 line-clamp-3">
                    {service.description}
                  </p>
                </div>

                {/* Bottom Action Links */}
                <div className="pt-4 border-t border-[#E7E0D6]/60 flex items-center justify-between">
                  <button
                    id={`service-explore-${service.id}`}
                    onClick={() => onSelectService(service)}
                    className="editorial-link text-[12px] uppercase font-sans tracking-[0.18em] text-[#343434] hover:text-[#788875] font-medium inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <span>Explore</span>
                    <ArrowRight className="w-3.5 h-3.5 text-[#CBB58A] transition-transform duration-300 group-hover:translate-x-1" />
                  </button>

                  <button
                    id={`service-inquire-${service.id}`}
                    onClick={() => onBookService(service.title)}
                    className="text-[11px] uppercase tracking-[0.15em] text-[#788875] hover:text-[#343434] font-medium transition-colors cursor-pointer"
                  >
                    Inquire →
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};
