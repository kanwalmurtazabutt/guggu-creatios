import React from 'react';
import { ArrowRight, Check } from 'lucide-react';
import { FEATURED_BOOK_IMAGE } from '../data/content';

interface FeaturedMemoryBookProps {
  onViewJournalsClick: () => void;
  onInquireClick: () => void;
}

export const FeaturedMemoryBook: React.FC<FeaturedMemoryBookProps> = ({
  onViewJournalsClick,
  onInquireClick
}) => {
  const highlights = [
    { title: 'Personalized layouts', desc: 'Customized typography, colors, and dedication pages for your child' },
    { title: 'Photo-ready pages', desc: 'Curated framing for ultrasound scans, newborn portraits, and candids' },
    { title: 'Meaningful prompts', desc: 'Gentle, thoughtful writing cues that make recording memories a pleasure' },
    { title: 'Premium editorial design', desc: 'Museum-grade typography and balanced white space that never dates' }
  ];

  return (
    <section
      id="baby-journals"
      className="relative bg-[#F8F5EE] py-24 sm:py-32 lg:py-36 px-6 sm:px-8 lg:px-12 overflow-hidden border-b border-[#E7E0D6]"
    >
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Large Editorial Lifestyle Photograph */}
          <div className="lg:col-span-7 order-2 lg:order-1">
            <div className="relative group">
              {/* Outer delicate border frame */}
              <div className="relative p-2 sm:p-3 bg-[#FBFAF6] border border-[#E7E0D6] rounded-[2px] shadow-[0_20px_50px_rgba(52,52,52,0.06)]">
                <div className="relative aspect-[4/3] overflow-hidden rounded-[1px] bg-[#E7E0D6]">
                  <img
                    src={FEATURED_BOOK_IMAGE}
                    alt="Luxury heirloom baby memory book displayed on white linen with knit baby shoes and dried chamomile in warm morning sunlight"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-1000 ease-out group-hover:scale-103"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#343434]/20 via-transparent to-transparent opacity-40"></div>
                </div>

                {/* Floating caption pill */}
                <div className="absolute -bottom-4 right-6 sm:right-8 bg-[#F8F5EE]/95 backdrop-blur-md px-5 py-2.5 border border-[#CBB58A]/40 shadow-md">
                  <p className="text-[11px] font-sans tracking-[0.16em] uppercase text-[#788875] font-medium flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#CBB58A]"></span>
                    Heirloom Linen &amp; Debossed Gold
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Editorial Copy & Highlights */}
          <div className="lg:col-span-5 order-1 lg:order-2 flex flex-col">
            {/* Eyebrow */}
            <div className="flex items-center gap-3 mb-4">
              <span className="text-[11px] uppercase font-sans tracking-[0.24em] text-[#788875] font-semibold">
                BABY MEMORY BOOKS
              </span>
              <span className="w-8 h-[1px] bg-[#CBB58A]"></span>
            </div>

            {/* Heading */}
            <h2 className="font-serif text-[36px] sm:text-[46px] lg:text-[52px] leading-[1.14] text-[#343434] font-normal tracking-[-0.01em] mb-6">
              For the little moments you never want to forget.
            </h2>

            {/* Body */}
            <p className="text-[16px] sm:text-[17px] leading-[1.7] font-sans text-[#77736C] mb-8 font-light">
              Capture first smiles, tiny habits, favorite photographs, milestones, family notes, and all the beautiful details that make your baby&apos;s story uniquely yours.
            </p>

            {/* Champagne Gold Separator */}
            <div className="w-full h-[1px] bg-[#CBB58A]/50 mb-8"></div>

            {/* Feature List */}
            <div className="space-y-4 mb-10">
              {highlights.map((item, idx) => (
                <div key={idx} className="flex items-start gap-3.5">
                  <div className="mt-1 flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-[#AAB7A0]/25 text-[#788875]">
                    <Check className="w-2.5 h-2.5 stroke-[2.5]" />
                  </div>
                  <div>
                    <h3 className="text-[14.5px] font-sans font-medium text-[#343434]">
                      {item.title}
                    </h3>
                    <p className="text-[13px] font-sans text-[#77736C] leading-snug">
                      {item.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-5 pt-2">
              <button
                id="featured-view-journals-btn"
                onClick={onViewJournalsClick}
                className="editorial-link group inline-flex items-center gap-2 text-[12.5px] uppercase font-sans tracking-[0.2em] text-[#343434] hover:text-[#788875] font-semibold py-1 cursor-pointer"
              >
                <span>View Baby Journals</span>
                <ArrowRight className="w-4 h-4 text-[#CBB58A] transition-transform duration-300 group-hover:translate-x-1" />
              </button>

              <button
                id="featured-commission-btn"
                onClick={onInquireClick}
                className="inline-flex items-center justify-center bg-[#788875] text-[#F8F5EE] text-[11px] uppercase tracking-[0.18em] px-6 py-2.5 rounded-[2px] hover:bg-[#343434] transition-all duration-300 shadow-[0_2px_8px_rgba(52,52,52,0.08)] cursor-pointer"
              >
                Commission Yours
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
