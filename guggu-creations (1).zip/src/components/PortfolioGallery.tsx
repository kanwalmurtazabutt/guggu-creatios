import React, { useState } from 'react';
import { ArrowRight, Eye } from 'lucide-react';
import { PORTFOLIO_ITEMS } from '../data/content';
import { PortfolioItem, ProjectCategory } from '../types';

interface PortfolioGalleryProps {
  onSelectProject: (project: PortfolioItem) => void;
}

export const PortfolioGallery: React.FC<PortfolioGalleryProps> = ({ onSelectProject }) => {
  const [activeCategory, setActiveCategory] = useState<ProjectCategory>('All');

  const categories: ProjectCategory[] = [
    'All',
    'Baby Memory Books',
    'Baby Journals',
    'eBook Covers',
    'eBook Interior Design',
    'Keepsake Journals',
    'Personalized Books'
  ];

  const filteredProjects =
    activeCategory === 'All'
      ? PORTFOLIO_ITEMS
      : PORTFOLIO_ITEMS.filter((item) => item.category === activeCategory);

  return (
    <section
      id="portfolio"
      className="relative bg-[#FBFAF6] py-24 sm:py-32 lg:py-36 px-6 sm:px-8 lg:px-12 border-b border-[#E7E0D6]"
    >
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14 sm:mb-16">
          <span className="text-[11px] uppercase font-sans tracking-[0.24em] text-[#788875] font-medium block mb-3">
            Selected Commissions &amp; Editions
          </span>
          <h2 className="font-serif text-[38px] sm:text-[48px] lg:text-[58px] leading-[1.12] text-[#343434] font-normal tracking-[-0.01em] mb-6">
            A collection of stories, beautifully told.
          </h2>
          <p className="text-[16px] sm:text-[17px] text-[#77736C] font-sans font-light max-w-xl mx-auto">
            Explore bespoke journals, custom book designs, and digital publications crafted for clients who believe in stories worth preserving.
          </p>
        </div>

        {/* Filter Navigation Tabs */}
        <div className="flex items-center justify-center flex-wrap gap-2 sm:gap-3 mb-14">
          {categories.map((cat) => (
            <button
              key={cat}
              id={`portfolio-filter-${cat.toLowerCase().replace(/\s+/g, '-')}`}
              onClick={() => setActiveCategory(cat)}
              className={`text-[11px] sm:text-[12px] uppercase font-sans tracking-[0.16em] px-4 py-2 rounded-[2px] transition-all duration-300 cursor-pointer ${
                activeCategory === cat
                  ? 'bg-[#343434] text-[#F8F5EE] shadow-sm'
                  : 'bg-[#F8F5EE] text-[#77736C] border border-[#E7E0D6] hover:text-[#343434] hover:border-[#788875]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Asymmetric / Editorial Gallery Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 sm:gap-10">
          {filteredProjects.map((project, index) => {
            // Asymmetric visual rhythm: 1st item spans 2 cols on desktop for editorial emphasis
            const isFeatured = index === 0 && activeCategory === 'All';

            return (
              <div
                key={project.id}
                id={`portfolio-item-${project.id}`}
                onClick={() => onSelectProject(project)}
                className={`group cursor-pointer relative bg-[#F8F5EE] border border-[#E7E0D6] rounded-[2px] overflow-hidden transition-all duration-500 hover:shadow-[0_16px_36px_rgba(52,52,52,0.08)] ${
                  isFeatured ? 'md:col-span-2 lg:col-span-2' : ''
                }`}
              >
                {/* Image container */}
                <div
                  className={`relative overflow-hidden bg-[#E7E0D6] ${
                    isFeatured ? 'aspect-[16/10] sm:aspect-[16/9]' : 'aspect-[4/3] sm:aspect-[4/3]'
                  }`}
                >
                  <img
                    src={project.coverImage}
                    alt={project.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-104"
                  />

                  {/* Soft Editorial Overlay on hover */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#343434]/70 via-[#343434]/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col justify-end p-6 sm:p-8">
                    <div className="translate-y-2 group-hover:translate-y-0 transition-transform duration-500">
                      <span className="text-[10px] sm:text-[11px] uppercase font-sans tracking-[0.2em] text-[#CBB58A] font-medium block mb-1">
                        {project.category}
                      </span>
                      <h4 className="font-serif text-[22px] sm:text-[26px] text-[#F8F5EE] leading-tight mb-2">
                        {project.title}
                      </h4>
                      <div className="inline-flex items-center gap-2 text-[12px] uppercase font-sans tracking-[0.18em] text-[#F8F5EE]/90">
                        <span>View Project</span>
                        <ArrowRight className="w-3.5 h-3.5 text-[#CBB58A]" />
                      </div>
                    </div>
                  </div>

                  {/* Quick Inspect Icon Button */}
                  <div className="absolute top-4 right-4 h-9 w-9 rounded-full bg-[#F8F5EE]/90 backdrop-blur-md flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 shadow-sm text-[#343434]">
                    <Eye className="w-4 h-4 text-[#788875]" />
                  </div>
                </div>

                {/* Card Meta Content underneath */}
                <div className="p-6">
                  <div className="flex items-center justify-between gap-4 mb-2">
                    <span className="text-[10px] uppercase font-sans tracking-[0.2em] text-[#788875] font-medium">
                      {project.category}
                    </span>
                    {project.dimensions && (
                      <span className="text-[11px] font-sans text-[#77736C]/70">
                        {project.dimensions}
                      </span>
                    )}
                  </div>
                  <h3 className="font-serif text-[22px] sm:text-[24px] text-[#343434] group-hover:text-[#788875] transition-colors mb-2">
                    {project.title}
                  </h3>
                  <p className="text-[14px] text-[#77736C] font-sans leading-relaxed line-clamp-2 font-light">
                    {project.subtitle}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
