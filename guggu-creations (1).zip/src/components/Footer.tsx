import React from 'react';
import { ArrowUp } from 'lucide-react';
import { Logo } from './Logo';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navLinks = [
    { label: 'Home', href: '#home' },
    { label: 'Services', href: '#services' },
    { label: 'Baby Journals', href: '#baby-journals' },
    { label: 'Sample Keepsake', href: '#keepsakes' },
    { label: 'Portfolio', href: '#portfolio' },
    { label: 'About', href: '#about' },
    { label: 'Contact', href: '#contact' }
  ];

  const serviceLinks = [
    { label: 'eBook Writing', href: '#services' },
    { label: 'eBook Design & Covers', href: '#services' },
    { label: 'Baby Memory Books', href: '#baby-journals' },
    { label: 'Heirloom Journals', href: '#keepsakes' },
    { label: 'Personalized Book Design', href: '#services' }
  ];

  const socialLinks = [
    { label: 'Instagram', href: 'https://instagram.com' },
    { label: 'Pinterest', href: 'https://pinterest.com' },
    { label: 'Facebook', href: 'https://facebook.com' }
  ];

  return (
    <footer
      id="main-footer"
      className="bg-[#343434] text-[#F8F5EE] pt-20 pb-12 px-6 sm:px-8 lg:px-12 border-t border-[#343434]"
    >
      <div className="max-w-7xl mx-auto">
        {/* Top Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12 lg:gap-16 pb-16 border-b border-[#F8F5EE]/10">
          {/* Brand Column */}
          <div className="lg:col-span-5 flex flex-col">
            <div className="mb-5">
              <Logo variant="dark" showTagline={true} />
            </div>
            <p className="text-[14.5px] font-sans font-light text-[#F8F5EE]/75 max-w-sm leading-relaxed mb-6">
              Premium digital publishing and personalized book design for stories worth remembering.
            </p>
            <div className="text-[12px] font-sans tracking-[0.15em] uppercase text-[#CBB58A]">
              Boutique Creative Studio • Est. 2026
            </div>
          </div>

          {/* Navigation Links Column */}
          <div className="lg:col-span-3">
            <span className="text-[10.5px] uppercase font-sans tracking-[0.24em] text-[#AAB7A0] font-medium block mb-5">
              Studio Navigation
            </span>
            <ul className="space-y-3 text-[13.5px] font-sans text-[#F8F5EE]/80">
              {navLinks.map((item) => (
                <li key={item.label}>
                  <a
                    href={item.href}
                    id={`footer-nav-${item.label.toLowerCase().replace(/\s+/g, '-')}`}
                    className="hover:text-[#CBB58A] transition-colors"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services Column */}
          <div className="lg:col-span-2">
            <span className="text-[10.5px] uppercase font-sans tracking-[0.24em] text-[#AAB7A0] font-medium block mb-5">
              Services
            </span>
            <ul className="space-y-3 text-[13.5px] font-sans text-[#F8F5EE]/80">
              {serviceLinks.map((item) => (
                <li key={item.label}>
                  <a
                    href={item.href}
                    id={`footer-service-${item.label.toLowerCase().replace(/\s+/g, '-')}`}
                    className="hover:text-[#CBB58A] transition-colors"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Social Links Column */}
          <div className="lg:col-span-2">
            <span className="text-[10.5px] uppercase font-sans tracking-[0.24em] text-[#AAB7A0] font-medium block mb-5">
              Follow Along
            </span>
            <ul className="space-y-3 text-[13.5px] font-sans text-[#F8F5EE]/80">
              {socialLinks.map((item) => (
                <li key={item.label}>
                  <a
                    href={item.href}
                    target="_blank"
                    rel="noreferrer"
                    id={`footer-social-${item.label.toLowerCase()}`}
                    className="hover:text-[#CBB58A] transition-colors inline-flex items-center gap-1.5"
                  >
                    <span>{item.label}</span>
                    <span className="text-[10px] text-[#CBB58A]/60">↗</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Line & Legal */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[12px] font-sans text-[#F8F5EE]/60">
          <p>© 2026 Guggu Creations. All rights reserved.</p>

          <div className="flex items-center gap-6">
            <a href="#privacy" className="hover:text-[#F8F5EE] transition-colors">
              Privacy Policy
            </a>
            <span>•</span>
            <a href="#terms" className="hover:text-[#F8F5EE] transition-colors">
              Terms of Service
            </a>
            <span>•</span>
            <a href="#accessibility" className="hover:text-[#F8F5EE] transition-colors">
              Accessibility
            </a>
          </div>

          <div>
            <button
              onClick={scrollToTop}
              id="back-to-top-btn"
              className="inline-flex items-center gap-2 hover:text-[#CBB58A] transition-colors text-[11px] uppercase tracking-[0.16em] cursor-pointer"
              aria-label="Back to top"
            >
              <span>Back to top</span>
              <ArrowUp className="w-3.5 h-3.5 text-[#CBB58A]" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
