import React from 'react';
import { HOW_IT_WORKS_STEPS } from '../data/content';

export const HowItWorks: React.FC = () => {
  return (
    <section
      id="how-it-works"
      className="relative bg-[#F8F5EE] py-24 sm:py-32 lg:py-36 px-6 sm:px-8 lg:px-12 border-b border-[#E7E0D6]"
    >
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="max-w-2xl mb-16 sm:mb-20">
          <span className="text-[11px] uppercase font-sans tracking-[0.24em] text-[#788875] font-medium block mb-3">
            The Creative Journey
          </span>
          <h2 className="font-serif text-[38px] sm:text-[48px] lg:text-[56px] leading-[1.12] text-[#343434] font-normal tracking-[-0.01em] mb-5">
            From idea to keepsake.
          </h2>
          <p className="text-[16px] text-[#77736C] font-sans font-light leading-relaxed">
            Our collaborative studio process is gentle, organized, and deeply personalized at every milestone.
          </p>
        </div>

        {/* 4 Steps Grid with Large Numerals and Thin Dividers */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-10">
          {HOW_IT_WORKS_STEPS.map((step, idx) => (
            <div
              key={step.number}
              id={`process-step-${step.number}`}
              className="relative flex flex-col pt-8 border-t border-[#CBB58A]/50 group"
            >
              {/* Large Serif Numeral */}
              <div className="font-serif text-[44px] sm:text-[52px] leading-none text-[#788875]/70 font-light mb-4 group-hover:text-[#343434] transition-colors">
                {step.number}
              </div>

              {/* Step Title */}
              <h3 className="font-serif text-[22px] sm:text-[24px] text-[#343434] mb-3 leading-snug">
                {step.title.replace(/^\d+\s*—\s*/, '')}
              </h3>

              {/* Step Description */}
              <p className="text-[14.5px] sm:text-[15px] leading-[1.7] text-[#77736C] font-sans font-light">
                {step.description}
              </p>

              {/* Progress Indicator line */}
              <div className="mt-8 flex items-center gap-1.5 text-[11px] text-[#788875] font-sans uppercase tracking-[0.18em]">
                <span className="w-1.5 h-1.5 rounded-full bg-[#AAB7A0]"></span>
                <span>Stage {idx + 1} of 4</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
