import React, { useState, useEffect } from 'react';
import { Menu, X, ArrowUpRight } from 'lucide-react';
import { Logo } from './Logo';

interface HeaderProps {
  onStartProjectClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onStartProjectClick }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 30);

      const sections = ['home', 'services', 'baby-journals', 'keepsakes', 'portfolio', 'about', 'contact'];
      const scrollPosition = window.scrollY + 180;

      for (const sectionId of sections) {
        const el = document.getElementById(sectionId);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Home', href: '#home', id: 'home' },
    { label: 'eBooks', href: '#services', id: 'services' },
    { label: 'Baby Journals', href: '#baby-journals', id: 'baby-journals' },
    { label: 'Keepsakes', href: '#keepsakes', id: 'keepsakes' },
    { label: 'Portfolio', href: '#portfolio', id: 'portfolio' },
    { label: 'About', href: '#about', id: 'about' },
    { label: 'Contact', href: '#contact', id: 'contact' }
  ];

  const handleNavClick = (href: string) => {
    setMobileMenuOpen(false);
    const targetId = href.replace('#', '');
    const element = document.getElementById(targetId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      id="main-header"
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-500 ease-out"
    >
      {/* Very slim announcement strip */}
      <div
        id="announcement-strip"
        className={`w-full bg-[#343434] text-[#F8F5EE] py-1.5 px-4 text-center text-[10.5px] font-sans tracking-[0.2em] uppercase transition-all duration-300 ${
          isScrolled ? 'h-0 py-0 opacity-0 overflow-hidden' : 'opacity-100'
        }`}
      >
        <span className="inline-flex items-center gap-2">
          <span className="h-1 w-1 rounded-full bg-[#CBB58A]"></span>
          Boutique Publishing &amp; Personalized Keepsakes • Accepting 2026/2027 Commissions
          <span className="h-1 w-1 rounded-full bg-[#CBB58A]"></span>
        </span>
      </div>

      {/* Main navigation bar */}
      <nav
        id="navigation-bar"
        className={`w-full transition-all duration-500 ${
          isScrolled
            ? 'bg-[#F8F5EE]/95 backdrop-blur-md shadow-[0_4px_24px_rgba(52,52,52,0.04)] border-b border-[#E7E0D6] py-3.5'
            : 'bg-[#F8F5EE]/80 backdrop-blur-sm border-b border-[#E7E0D6]/50 py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 flex items-center justify-between">
          {/* Brand Logo */}
          <div className="flex items-center">
            <Logo showTagline={!isScrolled} />
          </div>

          {/* Desktop Navigation Links */}
          <ul className="hidden md:flex items-center gap-7 lg:gap-9">
            {navLinks.map((link) => {
              const isActive = activeSection === link.id;
              return (
                <li key={link.label}>
                  <a
                    href={link.href}
                    id={`nav-link-${link.id}`}
                    onClick={(e) => {
                      e.preventDefault();
                      handleNavClick(link.href);
                    }}
                    className={`text-[11.5px] uppercase font-sans tracking-[0.16em] transition-all duration-300 relative py-1 ${
                      isActive
                        ? 'text-[#343434] font-medium'
                        : 'text-[#77736C] hover:text-[#343434]'
                    }`}
                  >
                    {link.label}
                    {isActive && (
                      <span className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-[#788875] rounded-full transition-all"></span>
                    )}
                  </a>
                </li>
              );
            })}
          </ul>

          {/* Right Action Button */}
          <div className="hidden md:flex items-center gap-4">
            <button
              id="header-cta-button"
              onClick={onStartProjectClick}
              className="inline-flex items-center gap-2 bg-[#343434] text-[#F8F5EE] text-[11px] uppercase tracking-[0.18em] px-6 py-2.5 rounded-[2px] transition-all duration-300 hover:bg-[#788875] hover:-translate-y-0.5 active:translate-y-0 shadow-[0_2px_8px_rgba(52,52,52,0.08)] cursor-pointer"
            >
              <span>Start Your Project</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-[#CBB58A]" />
            </button>
          </div>

          {/* Mobile Hamburger Button */}
          <div className="flex md:hidden items-center">
            <button
              id="mobile-menu-toggle-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2.5 text-[#343434] hover:text-[#788875] transition-colors focus:outline-none focus:ring-1 focus:ring-[#788875]"
              aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div
            id="mobile-navigation-drawer"
            className="md:hidden bg-[#F8F5EE] border-b border-[#E7E0D6] shadow-xl px-6 pt-4 pb-8 transition-all duration-300 animate-fadeIn"
          >
            <ul className="flex flex-col space-y-4 pt-2">
              {navLinks.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    id={`mobile-nav-${link.id}`}
                    onClick={(e) => {
                      e.preventDefault();
                      handleNavClick(link.href);
                    }}
                    className="block text-[14px] uppercase font-sans tracking-[0.18em] text-[#343434] hover:text-[#788875] py-2 border-b border-[#E7E0D6]/40"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
            <div className="mt-6 pt-2">
              <button
                id="mobile-menu-cta-btn"
                onClick={() => {
                  setMobileMenuOpen(false);
                  onStartProjectClick();
                }}
                className="w-full flex items-center justify-center gap-2 bg-[#343434] text-[#F8F5EE] text-[12px] uppercase tracking-[0.18em] py-3.5 rounded-[2px] hover:bg-[#788875] transition-colors cursor-pointer"
              >
                <span>Start Your Project</span>
                <ArrowUpRight className="w-4 h-4 text-[#CBB58A]" />
              </button>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
};
