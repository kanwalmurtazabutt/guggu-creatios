import React from 'react';
import { ArrowRight } from 'lucide-react';

interface IntroductionProps {
  onDiscoverStudioClick: () => void;
}

export const Introduction: React.FC<IntroductionProps> = ({ onDiscoverStudioClick }) => {
  return (
    <section
      id="introduction"
      className="relative bg-[#F8F5EE] py-20 sm:py-28 lg:py-36 px-6 sm:px-8 lg:px-12 border-t border-b border-[#E7E0D6]/60"
    >
      <div className="max-w-4xl mx-auto text-center">
        {/* Centered Small Uppercase Eyebrow */}
        <div className="flex items-center justify-center gap-3 mb-6">
          <span className="w-8 h-[1px] bg-[#CBB58A]"></span>
          <span className="text-[11px] sm:text-[12px] uppercase font-sans tracking-[0.28em] text-[#788875] font-medium">
            WELCOME TO GUGGU CREATIONS
          </span>
          <span className="w-8 h-[1px] bg-[#CBB58A]"></span>
        </div>

        {/* Large Serif Heading */}
        <h2 className="font-serif text-[36px] sm:text-[50px] lg:text-[62px] leading-[1.12] text-[#343434] font-normal tracking-[-0.01em] mb-8 max-w-3xl mx-auto text-balance">
          Where your memories become beautiful books.
        </h2>

        {/* Supporting Editorial Paragraph */}
        <p className="text-[17px] sm:text-[19px] lg:text-[20px] leading-[1.75] font-sans text-[#77736C] max-w-2xl mx-auto mb-10 text-balance font-light">
          From the first tiny milestones to stories that deserve a beautiful home, Guggu Creations transforms ideas, photographs, words, and memories into thoughtfully designed digital books and keepsakes.
        </p>

        {/* Refined Text Link / Understated Button */}
        <div>
          <button
            id="intro-discover-studio-btn"
            onClick={onDiscoverStudioClick}
            className="editorial-link group inline-flex items-center gap-2.5 text-[13px] uppercase font-sans tracking-[0.2em] text-[#343434] hover:text-[#788875] font-medium py-1 transition-colors cursor-pointer"
          >
            <span>Discover the Studio</span>
            <ArrowRight className="w-4 h-4 text-[#CBB58A] transition-transform duration-300 group-hover:translate-x-1" />
          </button>
        </div>

        {/* Decorative thin motif */}
        <div className="mt-14 flex items-center justify-center gap-4 text-[#CBB58A]/60">
          <span className="w-12 h-[1px] bg-[#E7E0D6]"></span>
          <svg className="w-4 h-4 text-[#AAB7A0]" viewBox="0 0 24 24" fill="none" stroke="currentColor">
            <path d="M12 2C6.5 2 2 6.5 2 12C2 17.5 6.5 22 12 22C17.5 22 22 17.5 22 12" strokeWidth="1.2" strokeLinecap="round" />
            <path d="M12 6C9 6 7 8 7 11C7 15 12 18 12 18C12 18 17 15 17 11C17 8 15 6 12 6Z" fill="#CBB58A" fillOpacity="0.4" strokeWidth="1" />
          </svg>
          <span className="w-12 h-[1px] bg-[#E7E0D6]"></span>
        </div>
      </div>
    </section>
  );
};
