import React from 'react';
import { TESTIMONIALS } from '../data/content';

export const Testimonials: React.FC = () => {
  return (
    <section
      id="testimonials"
      className="relative bg-[#F8F5EE] py-24 sm:py-32 lg:py-36 px-6 sm:px-8 lg:px-12 border-b border-[#E7E0D6]"
    >
      <div className="max-w-7xl mx-auto">
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-16 sm:mb-20">
          <span className="text-[11px] uppercase font-sans tracking-[0.24em] text-[#788875] font-medium block mb-3">
            Client Reflections
          </span>
          <h2 className="font-serif text-[38px] sm:text-[46px] lg:text-[54px] leading-[1.14] text-[#343434] font-normal tracking-[-0.01em]">
            Kind words from thoughtful clients.
          </h2>
        </div>

        {/* 3 Testimonials in an Elegant Editorial Layout */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 lg:gap-14">
          {TESTIMONIALS.map((t) => (
            <div
              key={t.id}
              id={`testimonial-${t.id}`}
              className="flex flex-col justify-between bg-[#FBFAF6] border border-[#E7E0D6] p-8 sm:p-10 rounded-[2px] shadow-[0_4px_20px_rgba(52,52,52,0.03)]"
            >
              <div>
                {/* Subtle Editorial Quotation Mark */}
                <div className="font-serif text-[46px] leading-none text-[#CBB58A] mb-4 select-none">
                  “
                </div>

                {/* Testimonial Quote */}
                <p className="font-serif text-[18px] sm:text-[20px] leading-[1.65] text-[#343434] italic font-normal mb-8">
                  {t.quote}
                </p>
              </div>

              {/* Author and Project Details */}
              <div className="pt-6 border-t border-[#E7E0D6] flex items-center justify-between">
                <div>
                  <h3 className="font-sans text-[14px] font-semibold text-[#343434] tracking-[0.02em]">
                    {t.author}
                  </h3>
                  <p className="text-[12px] font-sans text-[#77736C]">
                    {t.location}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[10.5px] uppercase font-sans tracking-[0.16em] text-[#788875] font-medium block">
                    {t.projectCategory}
                  </span>
                  <span className="text-[11px] font-sans text-[#CBB58A]">
                    {t.year}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
