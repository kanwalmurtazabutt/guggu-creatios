import React from 'react';
import { ArrowRight } from 'lucide-react';
import { FAMILY_MOMENT_IMAGE } from '../data/content';

interface EmotionalStatementProps {
  onCreateMeaningfulClick: () => void;
}

export const EmotionalStatement: React.FC<EmotionalStatementProps> = ({
  onCreateMeaningfulClick
}) => {
  return (
    <section
      id="statement"
      className="relative min-h-[520px] sm:min-h-[580px] lg:min-h-[640px] flex items-center justify-center overflow-hidden"
    >
      {/* Cinematic Background Image */}
      <img
        src={FAMILY_MOMENT_IMAGE}
        alt="Tender and serene family moment in warm afternoon golden-hour light"
        referrerPolicy="no-referrer"
        className="absolute inset-0 w-full h-full object-cover object-center scale-[1.02]"
      />

      {/* Atmospheric Editorial Overlay */}
      <div className="absolute inset-0 bg-[#343434]/55 mix-blend-multiply"></div>
      <div className="absolute inset-0 bg-gradient-to-b from-[#343434]/40 via-transparent to-[#343434]/60"></div>
      <div className="absolute inset-0 bg-[#788875]/20 mix-blend-soft-light"></div>

      {/* Centered Content */}
      <div className="relative z-10 max-w-4xl mx-auto px-6 sm:px-8 text-center text-[#F8F5EE] py-20">
        <span className="inline-block text-[11px] sm:text-[12px] uppercase font-sans tracking-[0.3em] text-[#CBB58A] mb-8 font-medium">
          A Note on Remembering
        </span>

        {/* Serif Quote */}
        <blockquote className="font-serif text-[34px] sm:text-[46px] lg:text-[58px] leading-[1.18] font-normal tracking-[-0.01em] text-balance mb-8">
          “The smallest moments often become the stories we treasure most.”
        </blockquote>

        {/* Underneath Signature */}
        <p className="text-[14px] sm:text-[15px] font-sans tracking-[0.16em] uppercase text-[#F8F5EE]/85 mb-10 font-light">
          Designed with care by Guggu Creations.
        </p>

        {/* Subtle CTA */}
        <div>
          <button
            id="statement-meaningful-cta"
            onClick={onCreateMeaningfulClick}
            className="editorial-link group inline-flex items-center gap-2.5 text-[12px] sm:text-[13px] uppercase font-sans tracking-[0.24em] text-[#F8F5EE] hover:text-[#CBB58A] font-medium py-1 transition-colors cursor-pointer"
          >
            <span>Create Something Meaningful</span>
            <ArrowRight className="w-4 h-4 text-[#CBB58A] transition-transform duration-300 group-hover:translate-x-1" />
          </button>
        </div>
      </div>
    </section>
  );
};
