import React, { useState, useEffect } from 'react';
import { Mail, Clock, CheckCircle, Send, HelpCircle, ChevronDown, ChevronUp } from 'lucide-react';
import { InquiryFormData } from '../types';
import { FREQUENT_QUESTIONS } from '../data/content';

interface ContactSectionProps {
  preselectedService?: string;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ preselectedService }) => {
  const [formData, setFormData] = useState<InquiryFormData>({
    name: '',
    email: '',
    phone: '',
    projectType: 'Baby Memory Book',
    timeline: 'Within 1–2 months',
    budgetRange: '$500 – $1,500',
    message: ''
  });

  const [errors, setErrors] = useState<Partial<Record<keyof InquiryFormData, string>>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [activeFaqIndex, setActiveFaqIndex] = useState<number | null>(null);

  useEffect(() => {
    if (preselectedService) {
      setFormData((prev) => ({ ...prev, projectType: preselectedService }));
    }
  }, [preselectedService]);

  const validate = () => {
    const newErrors: Partial<Record<keyof InquiryFormData, string>> = {};
    if (!formData.name.trim()) newErrors.name = 'Please provide your full name.';
    if (!formData.email.trim() || !/^\S+@\S+\.\S+$/.test(formData.email)) {
      newErrors.email = 'Please provide a valid email address.';
    }
    if (!formData.message.trim() || formData.message.length < 15) {
      newErrors.message = 'Please share a few sentences about your story and vision (at least 15 characters).';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    // Simulate high-end boutique client onboarding response
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 900);
  };

  const projectTypes = [
    'eBook Writing',
    'eBook Design',
    'Baby Journal',
    'Baby Memory Book',
    'Keepsake Journal',
    'Personalized Book Design',
    'Other'
  ];

  const timelineOptions = [
    'As soon as possible',
    'Within 1–2 months',
    'Within 3–4 months',
    'Flexible / Planning ahead'
  ];

  return (
    <section
      id="contact"
      className="relative bg-[#FBFAF6] py-24 sm:py-32 lg:py-36 px-6 sm:px-8 lg:px-12 border-b border-[#E7E0D6]"
    >
      <div className="max-w-7xl mx-auto">
        {/* Section Heading */}
        <div className="max-w-2xl mb-16 sm:mb-20">
          <span className="text-[11px] uppercase font-sans tracking-[0.24em] text-[#788875] font-medium block mb-3">
            Inquiries &amp; Commissions
          </span>
          <h2 className="font-serif text-[38px] sm:text-[48px] lg:text-[56px] leading-[1.12] text-[#343434] font-normal tracking-[-0.01em] mb-4">
            Let’s create something meaningful.
          </h2>
          <p className="text-[16px] text-[#77736C] font-sans font-light leading-relaxed">
            Tell us about your story, baby’s milestones, or book vision. We personally review every inquiry and reply within 24–48 business hours with gentle guidance and availability.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
          {/* Left Column: Form or Success Card */}
          <div className="lg:col-span-7">
            {isSubmitted ? (
              <div
                id="contact-form-success"
                className="bg-[#F8F5EE] border border-[#AAB7A0] p-8 sm:p-12 rounded-[2px] shadow-[0_8px_30px_rgba(52,52,52,0.04)] text-center animate-fadeIn"
              >
                <div className="w-12 h-12 rounded-full bg-[#AAB7A0]/20 text-[#788875] flex items-center justify-center mx-auto mb-6">
                  <CheckCircle className="w-6 h-6" />
                </div>
                <h3 className="font-serif text-[30px] sm:text-[36px] text-[#343434] mb-3">
                  Thank you, {formData.name.split(' ')[0]}.
                </h3>
                <p className="text-[16px] text-[#77736C] font-sans font-light max-w-md mx-auto mb-6 leading-relaxed">
                  Your project inquiry for a <strong className="text-[#343434] font-medium">{formData.projectType}</strong> has been received by our studio. We look forward to reading your story.
                </p>
                <div className="p-4 bg-[#FBFAF6] border border-[#E7E0D6] rounded-[2px] text-[13px] text-[#788875] font-sans mb-8 max-w-sm mx-auto">
                  A confirmation summary has been logged for <span className="underline">{formData.email}</span>.
                </div>
                <button
                  id="reset-form-btn"
                  onClick={() => {
                    setIsSubmitted(false);
                    setFormData({
                      name: '',
                      email: '',
                      phone: '',
                      projectType: 'Baby Memory Book',
                      timeline: 'Within 1–2 months',
                      budgetRange: '$500 – $1,500',
                      message: ''
                    });
                  }}
                  className="editorial-link text-[12px] uppercase font-sans tracking-[0.18em] text-[#343434] hover:text-[#788875] font-semibold cursor-pointer"
                >
                  Send another inquiry
                </button>
              </div>
            ) : (
              <form
                id="project-inquiry-form"
                onSubmit={handleSubmit}
                className="bg-[#F8F5EE] border border-[#E7E0D6] p-7 sm:p-10 rounded-[2px] shadow-[0_6px_24px_rgba(52,52,52,0.03)] space-y-6"
                noValidate
              >
                {/* Row: Name & Email */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label
                      htmlFor="inquiry-name"
                      className="block text-[11.5px] uppercase font-sans tracking-[0.16em] text-[#343434] font-medium mb-2"
                    >
                      Your Name <span className="text-[#788875]">*</span>
                    </label>
                    <input
                      type="text"
                      id="inquiry-name"
                      name="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="e.g. Katherine Miller"
                      className={`w-full bg-[#FBFAF6] border ${
                        errors.name ? 'border-red-400' : 'border-[#E7E0D6]'
                      } px-4 py-3 text-[14.5px] text-[#343434] focus:outline-none focus:border-[#788875] rounded-[1px] transition-colors`}
                    />
                    {errors.name && (
                      <p className="mt-1 text-[12px] text-red-500 font-sans">{errors.name}</p>
                    )}
                  </div>

                  <div>
                    <label
                      htmlFor="inquiry-email"
                      className="block text-[11.5px] uppercase font-sans tracking-[0.16em] text-[#343434] font-medium mb-2"
                    >
                      Email Address <span className="text-[#788875]">*</span>
                    </label>
                    <input
                      type="email"
                      id="inquiry-email"
                      name="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="katherine@example.com"
                      className={`w-full bg-[#FBFAF6] border ${
                        errors.email ? 'border-red-400' : 'border-[#E7E0D6]'
                      } px-4 py-3 text-[14.5px] text-[#343434] focus:outline-none focus:border-[#788875] rounded-[1px] transition-colors`}
                    />
                    {errors.email && (
                      <p className="mt-1 text-[12px] text-red-500 font-sans">{errors.email}</p>
                    )}
                  </div>
                </div>

                {/* Row: Project Type & Timeline */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label
                      htmlFor="inquiry-project-type"
                      className="block text-[11.5px] uppercase font-sans tracking-[0.16em] text-[#343434] font-medium mb-2"
                    >
                      Project Type <span className="text-[#788875]">*</span>
                    </label>
                    <div className="relative">
                      <select
                        id="inquiry-project-type"
                        name="projectType"
                        value={formData.projectType}
                        onChange={(e) => setFormData({ ...formData, projectType: e.target.value })}
                        className="w-full bg-[#FBFAF6] border border-[#E7E0D6] px-4 py-3 text-[14.5px] text-[#343434] focus:outline-none focus:border-[#788875] rounded-[1px] appearance-none cursor-pointer"
                      >
                        {projectTypes.map((type) => (
                          <option key={type} value={type}>
                            {type}
                          </option>
                        ))}
                      </select>
                      <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#77736C] pointer-events-none" />
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="inquiry-timeline"
                      className="block text-[11.5px] uppercase font-sans tracking-[0.16em] text-[#343434] font-medium mb-2"
                    >
                      Preferred Timeline
                    </label>
                    <div className="relative">
                      <select
                        id="inquiry-timeline"
                        name="timeline"
                        value={formData.timeline}
                        onChange={(e) => setFormData({ ...formData, timeline: e.target.value })}
                        className="w-full bg-[#FBFAF6] border border-[#E7E0D6] px-4 py-3 text-[14.5px] text-[#343434] focus:outline-none focus:border-[#788875] rounded-[1px] appearance-none cursor-pointer"
                      >
                        {timelineOptions.map((opt) => (
                          <option key={opt} value={opt}>
                            {opt}
                          </option>
                        ))}
                      </select>
                      <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#77736C] pointer-events-none" />
                    </div>
                  </div>
                </div>

                {/* Message Textarea */}
                <div>
                  <label
                    htmlFor="inquiry-message"
                    className="block text-[11.5px] uppercase font-sans tracking-[0.16em] text-[#343434] font-medium mb-2"
                  >
                    Tell Us About Your Story or Vision <span className="text-[#788875]">*</span>
                  </label>
                  <textarea
                    id="inquiry-message"
                    name="message"
                    rows={4}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Share any details about your baby's milestones, book themes, photographs ready to include, or specific aesthetic desires..."
                    className={`w-full bg-[#FBFAF6] border ${
                      errors.message ? 'border-red-400' : 'border-[#E7E0D6]'
                    } px-4 py-3 text-[14.5px] text-[#343434] focus:outline-none focus:border-[#788875] rounded-[1px] transition-colors resize-y`}
                  ></textarea>
                  {errors.message && (
                    <p className="mt-1 text-[12px] text-red-500 font-sans">{errors.message}</p>
                  )}
                </div>

                {/* Submit Button */}
                <div className="pt-2">
                  <button
                    type="submit"
                    id="inquiry-submit-btn"
                    disabled={isSubmitting}
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-[#343434] text-[#F8F5EE] text-[11.5px] uppercase tracking-[0.2em] font-medium px-9 py-4 rounded-[2px] hover:bg-[#788875] hover:-translate-y-0.5 active:translate-y-0 transition-all duration-300 shadow-[0_2px_8px_rgba(52,52,52,0.1)] cursor-pointer disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <span>Sending inquiry...</span>
                    ) : (
                      <>
                        <span>Send Project Inquiry</span>
                        <Send className="w-3.5 h-3.5 text-[#CBB58A]" />
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Right Column: Studio Contact Details & FAQ Accordion */}
          <div className="lg:col-span-5 flex flex-col justify-between">
            {/* Direct Studio Contacts */}
            <div className="bg-[#F8F5EE] border border-[#E7E0D6] p-7 sm:p-8 rounded-[2px] mb-8">
              <h3 className="font-serif text-[24px] text-[#343434] mb-4">
                Direct Studio Concierge
              </h3>
              <p className="text-[14px] text-[#77736C] font-sans font-light leading-relaxed mb-6">
                Prefer to write directly or need a tailored quote for an urgent milestone anniversary?
              </p>

              <div className="space-y-4 text-[14px] font-sans text-[#343434]">
                <div className="flex items-center gap-3">
                  <Mail className="w-4 h-4 text-[#788875]" />
                  <a
                    href="mailto:hello@guggucreations.com"
                    id="contact-direct-email"
                    className="hover:text-[#788875] transition-colors underline underline-offset-4 decoration-[#CBB58A]"
                  >
                    hello@guggucreations.com
                  </a>
                </div>

                <div className="flex items-center gap-3">
                  <Clock className="w-4 h-4 text-[#788875]" />
                  <span className="text-[#77736C]">
                    Monday – Friday, 9:00 AM – 6:00 PM EST
                  </span>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t border-[#E7E0D6] text-[12px] text-[#788875] font-sans">
                ✦ All initial creative consultations and outline reviews are complimentary.
              </div>
            </div>

            {/* Micro FAQ Accordion */}
            <div className="bg-[#F8F5EE] border border-[#E7E0D6] p-7 sm:p-8 rounded-[2px]">
              <div className="flex items-center gap-2 mb-4 text-[#343434]">
                <HelpCircle className="w-4 h-4 text-[#788875]" />
                <h3 className="font-serif text-[20px]">
                  Frequently Asked Questions
                </h3>
              </div>

              <div className="space-y-3">
                {FREQUENT_QUESTIONS.slice(0, 3).map((item, idx) => {
                  const isOpen = activeFaqIndex === idx;
                  return (
                    <div
                      key={idx}
                      className="border-b border-[#E7E0D6]/60 pb-3"
                    >
                      <button
                        type="button"
                        id={`faq-toggle-${idx}`}
                        onClick={() => setActiveFaqIndex(isOpen ? null : idx)}
                        className="w-full flex items-center justify-between text-left text-[13.5px] font-medium text-[#343434] hover:text-[#788875] transition-colors py-1 cursor-pointer"
                      >
                        <span>{item.question}</span>
                        {isOpen ? (
                          <ChevronUp className="w-3.5 h-3.5 text-[#788875] shrink-0 ml-2" />
                        ) : (
                          <ChevronDown className="w-3.5 h-3.5 text-[#77736C] shrink-0 ml-2" />
                        )}
                      </button>
                      {isOpen && (
                        <p className="mt-2 text-[13px] text-[#77736C] font-sans font-light leading-relaxed animate-fadeIn">
                          {item.answer}
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
