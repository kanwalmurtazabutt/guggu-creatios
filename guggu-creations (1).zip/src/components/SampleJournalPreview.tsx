import React, { useState } from 'react';
import { ArrowRight, Sparkles, CheckCircle2 } from 'lucide-react';
import { SAMPLE_JOURNAL_ANGLES } from '../data/content';

interface SampleJournalPreviewProps {
  onExploreJournalClick: () => void;
}

export const SampleJournalPreview: React.FC<SampleJournalPreviewProps> = ({
  onExploreJournalClick
}) => {
  const [activeAngleIndex, setActiveAngleIndex] = useState(1); // Default to Interior Spread
  const activeAngle = SAMPLE_JOURNAL_ANGLES[activeAngleIndex];

  return (
    <section
      id="keepsakes"
      className="relative bg-[#FBFAF6] py-24 sm:py-32 lg:py-36 px-6 sm:px-8 lg:px-12 border-b border-[#E7E0D6]"
    >
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="max-w-3xl mb-12 sm:mb-16">
          <span className="text-[11px] uppercase font-sans tracking-[0.24em] text-[#788875] font-medium block mb-3">
            Featured Heirloom Edition
          </span>
          <h2 className="font-serif text-[38px] sm:text-[48px] lg:text-[56px] leading-[1.14] text-[#343434] font-normal tracking-[-0.01em] mb-4">
            A keepsake made around your memories.
          </h2>
          <p className="text-[16px] sm:text-[17px] text-[#77736C] font-sans font-light max-w-2xl leading-relaxed">
            Every page is designed to give your photographs, words, milestones, and memories the space they deserve.
          </p>
        </div>

        {/* Interactive Angle Switcher Tabs */}
        <div className="flex items-center gap-2 sm:gap-3 overflow-x-auto pb-4 mb-8 border-b border-[#E7E0D6] scrollbar-none">
          {SAMPLE_JOURNAL_ANGLES.map((angle, idx) => (
            <button
              key={angle.id}
              id={`journal-angle-tab-${angle.id}`}
              onClick={() => setActiveAngleIndex(idx)}
              className={`whitespace-nowrap px-4 py-2.5 text-[11px] sm:text-[12px] uppercase font-sans tracking-[0.16em] transition-all duration-300 rounded-[2px] cursor-pointer ${
                activeAngleIndex === idx
                  ? 'bg-[#343434] text-[#F8F5EE] shadow-sm'
                  : 'bg-[#F8F5EE] text-[#77736C] border border-[#E7E0D6] hover:text-[#343434]'
              }`}
            >
              {angle.tabLabel}
            </button>
          ))}
        </div>

        {/* Showcase Display Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center bg-[#F8F5EE] border border-[#E7E0D6] p-6 sm:p-10 lg:p-12 rounded-[2px] shadow-[0_12px_36px_rgba(52,52,52,0.04)]">
          {/* Main Mockup Visual Frame */}
          <div className="lg:col-span-8">
            <div className="relative aspect-[16/10] overflow-hidden rounded-[2px] bg-[#E7E0D6] border border-[#E7E0D6] shadow-sm">
              <img
                src={activeAngle.image}
                alt={activeAngle.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-all duration-700 ease-out"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#343434]/25 via-transparent to-transparent opacity-40"></div>

              {/* Angle Tag Badge */}
              <div className="absolute bottom-4 left-4 bg-[#F8F5EE]/95 backdrop-blur-md px-3.5 py-1.5 border border-[#E7E0D6] rounded-[1px]">
                <span className="text-[10px] sm:text-[11px] font-sans font-medium tracking-[0.18em] uppercase text-[#788875] flex items-center gap-1.5">
                  <Sparkles className="w-3 h-3 text-[#CBB58A]" />
                  {activeAngle.tabLabel} Perspective
                </span>
              </div>
            </div>
          </div>

          {/* Perspective Details Column */}
          <div className="lg:col-span-4 flex flex-col justify-center">
            <span className="text-[10.5px] uppercase font-sans tracking-[0.22em] text-[#CBB58A] font-semibold mb-2">
              Page Anatomy
            </span>
            <h3 className="font-serif text-[28px] sm:text-[32px] text-[#343434] leading-[1.2] mb-4">
              {activeAngle.title}
            </h3>
            <p className="text-[15px] text-[#77736C] font-sans leading-[1.7] mb-6 font-light">
              {activeAngle.description}
            </p>

            {/* Micro Feature Bullet Points */}
            <ul className="space-y-2.5 mb-8">
              {activeAngle.features.map((feat, idx) => (
                <li key={idx} className="flex items-center gap-2.5 text-[13.5px] text-[#343434] font-sans">
                  <CheckCircle2 className="w-4 h-4 text-[#788875] shrink-0" />
                  <span>{feat}</span>
                </li>
              ))}
            </ul>

            {/* Action CTA */}
            <div>
              <button
                id="sample-explore-journal-btn"
                onClick={onExploreJournalClick}
                className="editorial-link inline-flex items-center gap-2 text-[12.5px] uppercase font-sans tracking-[0.2em] text-[#343434] hover:text-[#788875] font-semibold py-1 cursor-pointer"
              >
                <span>Explore the Journal</span>
                <ArrowRight className="w-4 h-4 text-[#CBB58A]" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
