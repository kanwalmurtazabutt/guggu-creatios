import React from 'react';
import { ArrowRight, Instagram } from 'lucide-react';
import { SOCIAL_GALLERY_IMAGES } from '../data/content';

export const SocialGallery: React.FC = () => {
  return (
    <section
      id="journal-moments"
      className="relative bg-[#F8F5EE] py-24 sm:py-32 px-6 sm:px-8 lg:px-12 border-b border-[#E7E0D6]"
    >
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-14 sm:mb-16 pb-6 border-b border-[#E7E0D6]">
          <div>
            <span className="text-[11px] uppercase font-sans tracking-[0.24em] text-[#788875] font-medium block mb-2">
              Studio Journal &amp; Moodboard
            </span>
            <h2 className="font-serif text-[36px] sm:text-[46px] lg:text-[52px] leading-[1.14] text-[#343434] font-normal tracking-[-0.01em]">
              Little details. Beautifully remembered.
            </h2>
          </div>
          <div className="mt-4 sm:mt-0">
            <a
              href="https://www.instagram.com"
              target="_blank"
              rel="noreferrer"
              id="social-instagram-link"
              className="editorial-link group inline-flex items-center gap-2 text-[12px] uppercase font-sans tracking-[0.2em] text-[#343434] hover:text-[#788875] font-semibold py-1"
            >
              <Instagram className="w-4 h-4 text-[#CBB58A]" />
              <span>Follow Guggu Creations</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#CBB58A] transition-transform duration-300 group-hover:translate-x-1" />
            </a>
          </div>
        </div>

        {/* Curated Grid of 6 Square/Portrait Images */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 sm:gap-6">
          {SOCIAL_GALLERY_IMAGES.map((item) => (
            <div
              key={item.id}
              id={`social-card-${item.id}`}
              className="group relative aspect-square overflow-hidden rounded-[2px] bg-[#E7E0D6] border border-[#E7E0D6] shadow-[0_4px_16px_rgba(52,52,52,0.03)]"
            >
              <img
                src={item.image}
                alt={item.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-108"
              />

              {/* Delicate hover overlay */}
              <div className="absolute inset-0 bg-[#343434]/60 opacity-0 group-hover:opacity-100 transition-opacity duration-400 flex flex-col justify-end p-4 text-[#F8F5EE]">
                <span className="text-[9px] uppercase font-sans tracking-[0.2em] text-[#CBB58A] font-medium">
                  {item.category}
                </span>
                <p className="font-serif text-[13px] leading-tight text-[#F8F5EE]">
                  {item.title}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
