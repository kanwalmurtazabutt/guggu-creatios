import React from 'react';
import { ArrowRight, Feather, BookOpen, Compass, Layers } from 'lucide-react';
import { STUDIO_DESK_IMAGE, STUDIO_VALUES } from '../data/content';

interface AboutStudioProps {
  onMeetStudioClick: () => void;
}

export const AboutStudio: React.FC<AboutStudioProps> = ({ onMeetStudioClick }) => {
  const pillars = [
    { icon: BookOpen, label: 'Editorial Design' },
    { icon: Feather, label: 'Storytelling' },
    { icon: Layers, label: 'Personalized Layouts' },
    { icon: Compass, label: 'Modern Luxury' }
  ];

  return (
    <section
      id="about"
      className="relative bg-[#FBFAF6] py-24 sm:py-32 lg:py-36 px-6 sm:px-8 lg:px-12 border-b border-[#E7E0D6]"
    >
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Editorial Studio Details */}
          <div className="lg:col-span-6 flex flex-col justify-center">
            <span className="text-[11px] uppercase font-sans tracking-[0.24em] text-[#788875] font-medium block mb-3">
              About the Studio
            </span>
            <h2 className="font-serif text-[38px] sm:text-[48px] lg:text-[54px] leading-[1.14] text-[#343434] font-normal tracking-[-0.01em] mb-6">
              Thoughtful design for meaningful stories.
            </h2>
            <p className="text-[17px] sm:text-[18px] leading-[1.7] font-sans text-[#343434] font-normal mb-5">
              Guggu Creations is a boutique creative publishing studio focused on turning words, photographs, ideas, and memories into beautifully designed books.
            </p>
            <p className="text-[15px] sm:text-[16px] leading-[1.75] font-sans text-[#77736C] font-light mb-8">
              We operate at the quiet intersection of literary discipline and tactile beauty. Whether documenting a baby’s fleeting first year, crafting a limited-run family memoir, or laying out a high-end digital eBook, we believe that the stories you hold dear deserve the utmost visual reverence and typographic craft.
            </p>

            {/* Studio Core Pillars */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-6 border-t border-b border-[#E7E0D6] mb-8">
              {pillars.map((p, idx) => {
                const IconComponent = p.icon;
                return (
                  <div key={idx} className="flex flex-col items-center sm:items-start text-center sm:text-left">
                    <IconComponent className="w-5 h-5 text-[#788875] mb-2" />
                    <span className="text-[12px] font-sans font-medium text-[#343434] tracking-[0.04em]">
                      {p.label}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* CTA */}
            <div>
              <button
                id="about-meet-studio-btn"
                onClick={onMeetStudioClick}
                className="editorial-link group inline-flex items-center gap-2.5 text-[12.5px] uppercase font-sans tracking-[0.2em] text-[#343434] hover:text-[#788875] font-semibold py-1 cursor-pointer"
              >
                <span>Meet Guggu Creations</span>
                <ArrowRight className="w-4 h-4 text-[#CBB58A] transition-transform duration-300 group-hover:translate-x-1" />
              </button>
            </div>
          </div>

          {/* Right Column: Warm Editorial Studio Photograph */}
          <div className="lg:col-span-6">
            <div className="relative group">
              <div className="relative p-3 bg-[#F8F5EE] border border-[#E7E0D6] rounded-[2px] shadow-[0_20px_50px_rgba(52,52,52,0.05)]">
                <div className="relative aspect-[4/3] overflow-hidden rounded-[1px] bg-[#E7E0D6]">
                  <img
                    src={STUDIO_DESK_IMAGE}
                    alt="Intimate boutique publishing studio desk with open linen journal, handmade paper samples, notes, and soft olive branches in morning sunlight"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-103"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#343434]/25 via-transparent to-transparent opacity-40"></div>
                </div>

                {/* Floating Quote Stamp */}
                <div className="mt-4 px-3 py-2 flex items-center justify-between text-[11px] font-sans tracking-[0.15em] uppercase text-[#77736C]">
                  <span>Studio Worktable • Curated Materials</span>
                  <span className="text-[#CBB58A] font-medium">Bespoke Only</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Studio Values Row */}
        <div className="mt-20 pt-14 border-t border-[#E7E0D6] grid grid-cols-1 md:grid-cols-3 gap-8">
          {STUDIO_VALUES.map((val, idx) => (
            <div key={idx} className="flex flex-col">
              <span className="text-[11px] font-sans font-medium uppercase tracking-[0.2em] text-[#CBB58A] mb-2">
                0{idx + 1} — Ethos
              </span>
              <h3 className="font-serif text-[22px] text-[#343434] mb-2">
                {val.title}
              </h3>
              <p className="text-[14px] text-[#77736C] font-sans font-light leading-relaxed">
                {val.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
