import React from 'react';
import { X, ArrowRight, Check } from 'lucide-react';
import { PortfolioItem, ServiceItem } from '../types';

interface ProjectModalProps {
  item: PortfolioItem | ServiceItem | null;
  type: 'portfolio' | 'service';
  onClose: () => void;
  onInquire: (title: string) => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({
  item,
  type,
  onClose,
  onInquire
}) => {
  if (!item) return null;

  const isPortfolio = type === 'portfolio';
  const portfolioItem = isPortfolio ? (item as PortfolioItem) : null;
  const serviceItem = !isPortfolio ? (item as ServiceItem) : null;

  const title = item.title;
  const image = isPortfolio ? portfolioItem!.coverImage : serviceItem!.image;
  const description = item.description;

  return (
    <div
      id="project-detail-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 lg:p-8 bg-[#343434]/70 backdrop-blur-sm animate-fadeIn"
      role="dialog"
      aria-modal="true"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto bg-[#F8F5EE] border border-[#E7E0D6] rounded-[2px] shadow-2xl p-6 sm:p-10 text-[#343434]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          id="close-modal-btn"
          className="absolute top-5 right-5 p-2 text-[#77736C] hover:text-[#343434] transition-colors rounded-full hover:bg-[#E7E0D6]/40 cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
          {/* Left Column: Imagery */}
          <div className="md:col-span-6">
            <div className="aspect-[4/3] rounded-[2px] overflow-hidden bg-[#E7E0D6] border border-[#E7E0D6] shadow-sm mb-4">
              <img
                src={image}
                alt={title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>

            {isPortfolio && portfolioItem?.additionalImages && portfolioItem.additionalImages.length > 0 && (
              <div className="grid grid-cols-2 gap-3">
                {portfolioItem.additionalImages.map((img, idx) => (
                  <div key={idx} className="aspect-[16/10] overflow-hidden rounded-[1px] border border-[#E7E0D6]">
                    <img
                      src={img}
                      alt={`${title} detail ${idx + 1}`}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Right Column: Editorial Notes & Details */}
          <div className="md:col-span-6 flex flex-col justify-between">
            <div>
              <span className="text-[11px] uppercase font-sans tracking-[0.22em] text-[#788875] font-semibold block mb-2">
                {isPortfolio ? portfolioItem?.category : `Service ${serviceItem?.number}`}
              </span>
              <h3 className="font-serif text-[30px] sm:text-[36px] leading-tight text-[#343434] mb-3">
                {title}
              </h3>

              {isPortfolio && portfolioItem?.subtitle && (
                <p className="text-[14.5px] font-sans text-[#788875] mb-4 font-medium">
                  {portfolioItem.subtitle}
                </p>
              )}

              <p className="text-[15px] font-sans text-[#77736C] leading-relaxed mb-6 font-light">
                {description}
              </p>

              {/* Specification List */}
              <div className="border-t border-b border-[#E7E0D6] py-4 mb-6 space-y-2.5">
                {isPortfolio && portfolioItem?.details.map((detail, idx) => (
                  <div key={idx} className="flex items-start gap-2.5 text-[13.5px] text-[#343434] font-sans">
                    <Check className="w-4 h-4 text-[#788875] shrink-0 mt-0.5" />
                    <span>{detail}</span>
                  </div>
                ))}

                {!isPortfolio && serviceItem?.deliverables.map((deliv, idx) => (
                  <div key={idx} className="flex items-start gap-2.5 text-[13.5px] text-[#343434] font-sans">
                    <Check className="w-4 h-4 text-[#788875] shrink-0 mt-0.5" />
                    <span>{deliv}</span>
                  </div>
                ))}
              </div>

              {!isPortfolio && serviceItem && (
                <div className="mb-6 text-[13px] font-sans text-[#77736C]">
                  <p className="mb-1"><strong className="text-[#343434] font-medium">Typical Timeline:</strong> {serviceItem.timeline}</p>
                  <p><strong className="text-[#343434] font-medium">Ideal For:</strong> {serviceItem.idealFor}</p>
                </div>
              )}
            </div>

            {/* Bottom Actions */}
            <div className="pt-2">
              <button
                id="modal-inquire-btn"
                onClick={() => {
                  onClose();
                  onInquire(title);
                }}
                className="w-full inline-flex items-center justify-center gap-2 bg-[#343434] text-[#F8F5EE] text-[11.5px] uppercase tracking-[0.2em] font-medium py-3.5 rounded-[2px] hover:bg-[#788875] transition-colors cursor-pointer shadow-sm"
              >
                <span>Inquire About This {isPortfolio ? 'Style' : 'Service'}</span>
                <ArrowRight className="w-4 h-4 text-[#CBB58A]" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
