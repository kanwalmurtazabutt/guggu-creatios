import React from 'react';
import { ArrowDown, Sparkles } from 'lucide-react';
import { HERO_IMAGE } from '../data/content';

interface HeroProps {
  onCreateKeepsakeClick: () => void;
  onExploreWorkClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  onCreateKeepsakeClick,
  onExploreWorkClick
}) => {
  return (
    <section
      id="home"
      className="relative min-h-[92vh] lg:min-h-screen flex items-center justify-center pt-28 pb-16 lg:pt-32 lg:pb-24 px-4 sm:px-6 lg:px-8 overflow-hidden bg-[#F8F5EE]"
    >
      {/* Editorial Frame Layout */}
      <div className="w-full max-w-7xl mx-auto">
        <div className="relative rounded-sm overflow-hidden border border-[#E7E0D6] shadow-[0_16px_40px_rgba(52,52,52,0.05)] bg-[#FBFAF6]">
          {/* Main Hero Photographic Canvas */}
          <div className="relative min-h-[620px] sm:min-h-[680px] lg:min-h-[760px] w-full flex items-center">
            {/* Background Lifestyle Photograph */}
            <img
              src={HERO_IMAGE}
              alt="Mother tenderly holding her newborn baby in an elegant ivory bedroom beside a keepsake memory journal"
              referrerPolicy="no-referrer"
              className="absolute inset-0 w-full h-full object-cover object-center lg:object-[60%_35%] scale-[1.01] transition-transform duration-1000 ease-out"
            />

            {/* Subtle editorial gradient overlay - refined warmth and text readability */}
            <div className="absolute inset-0 bg-gradient-to-r from-[#F8F5EE]/95 via-[#F8F5EE]/75 to-transparent sm:w-4/5 lg:w-3/5"></div>
            <div className="absolute inset-0 bg-gradient-to-t from-[#F8F5EE]/80 via-transparent to-[#F8F5EE]/25 sm:hidden"></div>

            {/* Fine art subtle vignette & warm tint */}
            <div className="absolute inset-0 pointer-events-none mix-blend-multiply bg-[#CBB58A]/5"></div>

            {/* Editorial Content Block */}
            <div className="relative z-10 max-w-2xl px-6 sm:px-12 lg:px-16 py-12 lg:py-20">
              {/* Eyebrow badge */}
              <div className="inline-flex items-center gap-2.5 px-3 py-1 bg-[#F8F5EE]/90 backdrop-blur-sm border border-[#E7E0D6] rounded-[2px] mb-6 sm:mb-8">
                <Sparkles className="w-3.5 h-3.5 text-[#CBB58A]" />
                <span className="text-[10px] sm:text-[11px] uppercase font-sans tracking-[0.24em] text-[#788875] font-medium">
                  Boutique Publishing &amp; Keepsake Studio
                </span>
              </div>

              {/* Main Headline */}
              <h1 className="font-serif text-[42px] sm:text-[58px] lg:text-[72px] leading-[1.08] tracking-[-0.01em] text-[#343434] font-normal text-balance mb-6">
                Beautifully designed stories.{' '}
                <span className="italic font-light text-[#788875] block sm:inline">
                  Made to be remembered.
                </span>
              </h1>

              {/* Supporting Copy */}
              <p className="text-[16px] sm:text-[18px] leading-[1.65] font-sans text-[#77736C] max-w-lg mb-8 sm:mb-10 text-balance">
                Premium eBooks, baby journals, memory books, and personalized keepsakes thoughtfully designed around your story.
              </p>

              {/* CTAs */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
                <button
                  id="hero-primary-cta"
                  onClick={onCreateKeepsakeClick}
                  className="inline-flex items-center justify-center bg-[#343434] text-[#F8F5EE] text-[11.5px] uppercase tracking-[0.2em] font-medium px-8 py-3.5 rounded-[2px] hover:bg-[#788875] hover:-translate-y-0.5 active:translate-y-0 transition-all duration-300 shadow-[0_4px_12px_rgba(52,52,52,0.12)] cursor-pointer"
                >
                  Create Your Keepsake
                </button>

                <button
                  id="hero-secondary-cta"
                  onClick={onExploreWorkClick}
                  className="inline-flex items-center justify-center bg-[#F8F5EE]/90 backdrop-blur-sm text-[#343434] border border-[#343434]/25 text-[11.5px] uppercase tracking-[0.2em] font-medium px-8 py-3.5 rounded-[2px] hover:bg-[#E7E0D6] hover:border-[#343434] hover:-translate-y-0.5 active:translate-y-0 transition-all duration-300 cursor-pointer"
                >
                  Explore Our Work
                </button>
              </div>

              {/* Small emotional hallmark */}
              <div className="mt-10 sm:mt-12 pt-6 border-t border-[#E7E0D6]/70 flex items-center gap-6 text-[12px] text-[#77736C] font-sans">
                <span className="flex items-center gap-1.5">
                  <span className="h-1.5 w-1.5 rounded-full bg-[#AAB7A0]"></span>
                  Heirloom Quality
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="h-1.5 w-1.5 rounded-full bg-[#CBB58A]"></span>
                  Custom Bespoke Design
                </span>
                <span className="hidden sm:flex items-center gap-1.5">
                  <span className="h-1.5 w-1.5 rounded-full bg-[#788875]"></span>
                  Digital &amp; Print Ready
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Subtle scroll indicator */}
        <div className="mt-8 flex justify-center items-center">
          <a
            href="#introduction"
            id="hero-scroll-indicator"
            className="group flex flex-col items-center gap-1.5 text-[10px] uppercase font-sans tracking-[0.24em] text-[#77736C] hover:text-[#343434] transition-colors"
            aria-label="Scroll down to introduction"
          >
            <span>Scroll to discover</span>
            <div className="w-5 h-8 border border-[#77736C]/40 rounded-full flex items-start justify-center p-1 group-hover:border-[#788875] transition-colors">
              <span className="w-1 h-2 bg-[#788875] rounded-full animate-bounce"></span>
            </div>
          </a>
        </div>
      </div>
    </section>
  );
};
