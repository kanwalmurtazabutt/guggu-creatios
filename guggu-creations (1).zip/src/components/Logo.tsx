import React from 'react';

interface LogoProps {
  className?: string;
  variant?: 'light' | 'dark' | 'auto';
  showTagline?: boolean;
}

export const Logo: React.FC<LogoProps> = ({
  className = '',
  variant = 'auto',
  showTagline = false
}) => {
  const isDark = variant === 'dark';

  return (
    <a
      href="#home"
      id="brand-logo-link"
      className={`group inline-flex items-center gap-3 transition-opacity duration-300 hover:opacity-85 ${className}`}
      aria-label="Guggu Creations Home"
    >
      {/* Established brand emblem: Simplified open-book + heart + botanical leaf */}
      <div className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-sm bg-[#F8F5EE] shadow-[0_1px_4px_rgba(52,52,52,0.06)] ring-1 ring-[#CBB58A]/30 transition-transform duration-500 group-hover:scale-105">
        <svg
          viewBox="0 0 40 40"
          className="h-6 w-6"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          aria-hidden="true"
        >
          {/* Subtle open book pages */}
          <path
            d="M20 12C16 8.5 9 9.5 7 14V30C9 26.5 16 25.5 20 29C24 25.5 31 26.5 33 30V14C31 9.5 24 8.5 20 12Z"
            stroke="#788875"
            strokeWidth="1.6"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {/* Central delicate heart symbol */}
          <path
            d="M20 15C20 15 18 12 15 12C12.5 12 11 13.8 11 16C11 19.8 20 24 20 24C20 24 29 19.8 29 16C29 13.8 27.5 12 25 12C22 12 20 15 20 15Z"
            fill="#CBB58A"
            fillOpacity="0.38"
            stroke="#CBB58A"
            strokeWidth="1.2"
            strokeLinejoin="round"
          />
          {/* Center spine */}
          <path
            d="M20 12V29"
            stroke="#788875"
            strokeWidth="1.4"
            strokeLinecap="round"
          />
          {/* Botanical leaf sprig unfurling from top of book */}
          <path
            d="M20 9C20 9 23.5 6 26.5 8C27.5 9.8 25.5 11.5 23.5 11.8"
            stroke="#AAB7A0"
            strokeWidth="1.3"
            strokeLinecap="round"
          />
          <path
            d="M20 9.5C19 8.2 16.5 7.8 15 9.2"
            stroke="#AAB7A0"
            strokeWidth="1.1"
            strokeLinecap="round"
          />
        </svg>
      </div>

      {/* Brand typographic signature */}
      <div className="flex flex-col">
        <span
          className={`font-serif text-[21px] font-medium tracking-[0.04em] leading-none ${
            isDark ? 'text-[#343434]' : 'text-[#343434]'
          }`}
        >
          Guggu Creations
        </span>
        {showTagline && (
          <span className="mt-1 text-[9px] font-sans font-medium uppercase tracking-[0.24em] text-[#788875]">
            Publishing &amp; Keepsakes
          </span>
        )}
      </div>
    </a>
  );
};
