import React from 'react';
import { ArrowUpRight } from 'lucide-react';

interface ConversionCTAProps {
  onStartProjectClick: () => void;
  onViewPortfolioClick: () => void;
}

export const ConversionCTA: React.FC<ConversionCTAProps> = ({
  onStartProjectClick,
  onViewPortfolioClick
}) => {
  return (
    <section
      id="conversion"
      className="relative bg-[#AAB7A0]/20 py-24 sm:py-32 lg:py-36 px-6 sm:px-8 lg:px-12 border-b border-[#E7E0D6] overflow-hidden"
    >
      {/* Decorative organic background watermark */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none opacity-[0.05]">
        <svg viewBox="0 0 100 100" className="w-[800px] h-[800px]" fill="none" stroke="#343434">
          <circle cx="50" cy="50" r="45" strokeWidth="0.5" />
          <circle cx="50" cy="50" r="35" strokeWidth="0.3" />
        </svg>
      </div>

      <div className="relative z-10 max-w-4xl mx-auto text-center">
        {/* Eyebrow */}
        <div className="flex items-center justify-center gap-3 mb-6">
          <span className="w-8 h-[1px] bg-[#CBB58A]"></span>
          <span className="text-[11px] sm:text-[12px] uppercase font-sans tracking-[0.26em] text-[#788875] font-semibold">
            Begin Your Heirloom
          </span>
          <span className="w-8 h-[1px] bg-[#CBB58A]"></span>
        </div>

        {/* Heading */}
        <h2 className="font-serif text-[38px] sm:text-[50px] lg:text-[60px] leading-[1.14] text-[#343434] font-normal tracking-[-0.01em] mb-6 text-balance">
          Have a story worth turning into a keepsake?
        </h2>

        {/* Supporting Copy */}
        <p className="text-[16px] sm:text-[18px] leading-[1.75] font-sans text-[#77736C] max-w-2xl mx-auto mb-10 font-light text-balance">
          Whether you are creating your first eBook, preserving your baby&apos;s milestones, or designing a personalized memory book, let&apos;s create something beautiful together.
        </p>

        {/* Dual CTAs */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            id="conversion-start-project-btn"
            onClick={onStartProjectClick}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-[#343434] text-[#F8F5EE] text-[11.5px] uppercase tracking-[0.2em] font-medium px-9 py-4 rounded-[2px] hover:bg-[#788875] hover:-translate-y-0.5 active:translate-y-0 transition-all duration-300 shadow-[0_4px_16px_rgba(52,52,52,0.12)] cursor-pointer"
          >
            <span>Start Your Project</span>
            <ArrowUpRight className="w-4 h-4 text-[#CBB58A]" />
          </button>

          <button
            id="conversion-view-portfolio-btn"
            onClick={onViewPortfolioClick}
            className="w-full sm:w-auto inline-flex items-center justify-center bg-[#FBFAF6] text-[#343434] border border-[#343434]/25 text-[11.5px] uppercase tracking-[0.2em] font-medium px-9 py-4 rounded-[2px] hover:bg-[#E7E0D6] hover:border-[#343434] hover:-translate-y-0.5 active:translate-y-0 transition-all duration-300 cursor-pointer"
          >
            View Portfolio
          </button>
        </div>
      </div>
    </section>
  );
};
